import { useEffect, useState } from "react";

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "/api";

const highlightItems = [
  { title: "Redis + Lua", desc: "库存预扣减与一人一单原子校验" },
  { title: "RabbitMQ", desc: "异步下单、削峰填谷、死信超时取消" },
  { title: "MySQL + MP", desc: "乐观锁回源扣减，避免数据库超卖" }
];

function formatMoney(value) {
  if (value === null || value === undefined) {
    return "--";
  }
  return `¥${Number(value).toFixed(2)}`;
}

function formatTime(value) {
  if (!value) {
    return "--";
  }
  return new Date(value).toLocaleString("zh-CN", {
    hour12: false
  });
}

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: {
      "Content-Type": "application/json"
    },
    ...options
  });
  const result = await response.json();
  if (!response.ok || result.code !== 0) {
    throw new Error(result.message || "请求失败");
  }
  return result.data;
}

export default function App() {
  const [products, setProducts] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [userId, setUserId] = useState("10001");
  const [orders, setOrders] = useState([]);
  const [message, setMessage] = useState("点击商品卡片查看详情并发起秒杀。");
  const [loadingProducts, setLoadingProducts] = useState(false);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    if (selectedId) {
      loadProductDetail(selectedId);
    }
  }, [selectedId]);

  async function loadProducts() {
    setLoadingProducts(true);
    try {
      const data = await request("/products");
      setProducts(data);
      if (data.length > 0) {
        setSelectedId((current) => current ?? data[0].id);
      }
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoadingProducts(false);
    }
  }

  async function loadProductDetail(productId) {
    setLoadingDetail(true);
    try {
      const data = await request(`/products/${productId}`);
      setSelectedProduct(data);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoadingDetail(false);
    }
  }

  async function loadOrders() {
    if (!userId) {
      setMessage("请先输入用户 ID。");
      return;
    }
    setLoadingOrders(true);
    try {
      const data = await request(`/orders?userId=${userId}`);
      setOrders(data);
      setMessage(`已加载用户 ${userId} 的订单列表。`);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoadingOrders(false);
    }
  }

  async function handleSeckill() {
    if (!selectedProduct) {
      return;
    }
    setSubmitting(true);
    try {
      const data = await request(`/seckill/${selectedProduct.id}`, {
        method: "POST",
        body: JSON.stringify({
          userId: Number(userId)
        })
      });
      setMessage(`抢购请求已提交，订单号 ${data.orderNo} 已进入异步链路。`);
      setTimeout(() => {
        loadProductDetail(selectedProduct.id);
        loadOrders();
      }, 800);
    } catch (error) {
      setMessage(error.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handlePay(orderNo) {
    try {
      await request(`/orders/${orderNo}/pay`, {
        method: "POST"
      });
      setMessage(`订单 ${orderNo} 已模拟支付。`);
      loadOrders();
    } catch (error) {
      setMessage(error.message);
    }
  }

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="hero-copy">
          <span className="eyebrow">GreatMall / 高并发秒杀电商平台</span>
          <h1>独立开源项目骨架，直接覆盖秒杀链路的关键设计点</h1>
          <p>
            前端基于 React，后端使用 Spring Boot + MySQL + Redis + RabbitMQ。
            页面聚焦商品详情、秒杀请求、异步订单与超时关闭主流程。
          </p>
        </div>
        <div className="highlight-grid">
          {highlightItems.map((item) => (
            <article key={item.title} className="highlight-card">
              <strong>{item.title}</strong>
              <p>{item.desc}</p>
            </article>
          ))}
        </div>
      </header>

      <main className="dashboard">
        <section className="panel">
          <div className="panel-head">
            <h2>秒杀商品池</h2>
            <button type="button" className="ghost-btn" onClick={loadProducts}>
              {loadingProducts ? "刷新中..." : "刷新列表"}
            </button>
          </div>
          <div className="product-grid">
            {products.map((product) => (
              <button
                type="button"
                key={product.id}
                className={`product-card ${selectedId === product.id ? "active" : ""}`}
                onClick={() => setSelectedId(product.id)}
              >
                <div
                  className="product-cover"
                  style={{
                    backgroundImage: product.coverImage
                      ? `linear-gradient(135deg, rgba(13, 20, 33, 0.35), rgba(13, 20, 33, 0.75)), url(${product.coverImage})`
                      : undefined
                  }}
                />
                <div className="product-content">
                  <span className="product-tag">
                    {product.seckillEnabled ? "SECKILL OPEN" : "STANDARD"}
                  </span>
                  <h3>{product.name}</h3>
                  <p>{product.subtitle}</p>
                  <div className="price-row">
                    <strong>{formatMoney(product.seckillPrice ?? product.price)}</strong>
                    <span>{formatMoney(product.price)}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </section>

        <section className="panel detail-panel">
          <div className="panel-head">
            <h2>商品详情</h2>
            <div className="user-box">
              <label htmlFor="userId">用户 ID</label>
              <input
                id="userId"
                value={userId}
                onChange={(event) => setUserId(event.target.value)}
                placeholder="10001"
              />
            </div>
          </div>

          {loadingDetail && <div className="empty-state">详情加载中...</div>}

          {!loadingDetail && selectedProduct && (
            <>
              <div
                className="detail-cover"
                style={{
                  backgroundImage: selectedProduct.coverImage
                    ? `linear-gradient(120deg, rgba(2, 12, 27, 0.25), rgba(2, 12, 27, 0.82)), url(${selectedProduct.coverImage})`
                    : undefined
                }}
              >
                <div className="detail-overlay">
                  <span className="eyebrow">热卖商品 #{selectedProduct.id}</span>
                  <h3>{selectedProduct.name}</h3>
                  <p>{selectedProduct.subtitle}</p>
                </div>
              </div>

              <div className="metric-row">
                <div className="metric-card">
                  <span>秒杀价</span>
                  <strong>{formatMoney(selectedProduct.seckillPrice)}</strong>
                </div>
                <div className="metric-card">
                  <span>原价</span>
                  <strong>{formatMoney(selectedProduct.price)}</strong>
                </div>
                <div className="metric-card">
                  <span>可售库存</span>
                  <strong>{selectedProduct.stock}</strong>
                </div>
                <div className="metric-card">
                  <span>累计售出</span>
                  <strong>{selectedProduct.soldCount ?? 0}</strong>
                </div>
              </div>

              <div className="detail-body">
                <p>{selectedProduct.description}</p>
                <div className="timeline">
                  <div>
                    <span>开始时间</span>
                    <strong>{formatTime(selectedProduct.seckillStartTime)}</strong>
                  </div>
                  <div>
                    <span>结束时间</span>
                    <strong>{formatTime(selectedProduct.seckillEndTime)}</strong>
                  </div>
                </div>
              </div>

              <button type="button" className="primary-btn" disabled={submitting} onClick={handleSeckill}>
                {submitting ? "提交中..." : "立即秒杀"}
              </button>
            </>
          )}
        </section>

        <section className="panel">
          <div className="panel-head">
            <h2>订单面板</h2>
            <button type="button" className="ghost-btn" onClick={loadOrders}>
              {loadingOrders ? "查询中..." : "查询订单"}
            </button>
          </div>

          <div className="message-bar">{message}</div>

          <div className="order-list">
            {orders.length === 0 && <div className="empty-state">当前用户暂无订单。</div>}
            {orders.map((order) => (
              <article className="order-card" key={order.orderNo}>
                <div>
                  <span className={`status-pill status-${order.status}`}>{order.statusText}</span>
                  <h3>{order.productName}</h3>
                  <p>订单号：{order.orderNo}</p>
                  <p>下单时间：{formatTime(order.createTime)}</p>
                </div>
                <div className="order-side">
                  <strong>{formatMoney(order.orderAmount)}</strong>
                  {order.status === 1 && (
                    <button type="button" className="ghost-btn" onClick={() => handlePay(order.orderNo)}>
                      模拟支付
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

